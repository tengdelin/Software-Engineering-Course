package com.example.demo.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.Student;
import com.example.demo.entity.User;

public interface StudentMapper extends BaseMapper<Student> {
//    Page<User> findPage(Page<User> page, @Param("nickName") String nickName);
}
