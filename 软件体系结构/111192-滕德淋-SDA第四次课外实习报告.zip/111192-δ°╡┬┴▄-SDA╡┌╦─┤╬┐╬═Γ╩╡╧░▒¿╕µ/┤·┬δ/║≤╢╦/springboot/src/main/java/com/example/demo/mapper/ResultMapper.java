package com.example.demo.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.CResult;

public interface ResultMapper extends BaseMapper<CResult> {
//    Page<User> findPage(Page<User> page, @Param("nickName") String nickName);
}
