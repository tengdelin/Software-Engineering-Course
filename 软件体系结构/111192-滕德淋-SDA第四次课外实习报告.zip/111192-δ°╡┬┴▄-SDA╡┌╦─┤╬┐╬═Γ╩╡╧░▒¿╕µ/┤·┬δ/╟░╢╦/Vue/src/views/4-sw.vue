<template>
实习四
</template>

<script>
export default {
  name: "1-ts"
}
</script>

<style scoped>

</style>