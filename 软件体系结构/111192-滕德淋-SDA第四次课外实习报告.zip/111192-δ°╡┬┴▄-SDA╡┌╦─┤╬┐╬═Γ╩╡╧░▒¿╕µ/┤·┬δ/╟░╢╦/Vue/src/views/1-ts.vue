<template>
实习一测试
</template>

<script>
export default {
  name: "1-ts"
}
</script>

<style scoped>

</style>