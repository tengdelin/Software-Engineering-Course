<template>
学生主页
</template>

<script>
export default {
  name: "Student-index"
}
</script>

<style scoped>

</style>