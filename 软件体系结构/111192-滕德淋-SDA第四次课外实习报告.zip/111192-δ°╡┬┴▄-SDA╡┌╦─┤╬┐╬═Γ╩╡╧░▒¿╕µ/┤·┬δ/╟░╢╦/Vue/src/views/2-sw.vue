<template>
实习二
</template>

<script>
export default {
  name: "1-ts"
}
</script>

<style scoped>

</style>