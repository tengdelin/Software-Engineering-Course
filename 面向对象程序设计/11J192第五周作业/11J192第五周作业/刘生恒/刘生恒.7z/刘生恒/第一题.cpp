﻿#include<iostream>

class CMystr
{
private:
	int m_length;
	int m_size;
public:
	char* m_str;
	CMystr()
	{
		m_length = 0;
		m_size = 16;
		m_str = (char*)malloc(m_size);
		for (int i = 0; i < m_size; ++i)
			m_str[i] = 0;
	}
	~CMystr()
	{
		free(m_str);
	}
	CMystr(CMystr& that)
	{
		this->m_length = that.m_length;
		this->m_size = that.m_size;
		m_str = (char*)malloc(m_size);
		int i = 0;
		while (i < m_size)
		{
			this->m_str[i] = that.m_str[i++];
		}
	}
	CMystr& operator = (const CMystr& other) // =赋以新值
	{
		if (this == &other)
			return *this;
		this->m_length = other.m_length;
		this->m_size = other.m_size;
		free(this->m_str);
		m_str = (char*)malloc(this->m_size);
		int i = 0;
		while (i < m_size)
		{
			this->m_str[i] = other.m_str[i++];
		}
		return *this;
	}
	CMystr& operator + (const CMystr& other) // +向后添加字符
	{
		CMystr Temp;
		Temp.m_length = this->m_length + other.m_length;
		while (Temp.m_length >= Temp.m_size) //扩容
			Temp.m_size *= 2;
		int i = 0;
		while (this->m_str[i])
		{
			Temp.m_str[i] = this->m_str[i++];
		}
		int j = 0;
		while (other.m_str[j])
		{
			Temp.m_str[i++] = other.m_str[j++];
		}
		*this = Temp;
		return *this;
	}
	int GetLength()
	{
		return m_length;
	}
	bool isEmpty()
	{
		return m_length == 0;
	}
	char At(int index)
	{
		if (index < m_length)
			return m_str[index];
		else
			return -1;
	}
	void insert(const char* a) //插入字符
	{
		int count = strlen(a);
		while (count + m_length >= m_size) //扩容
		{
			m_size *= 2;
		};
		int i = 0;
		while (a[i])
		{
			m_str[i] = a[i++];
			m_length++;
		}
		return;
	}
	bool erase(const char* a)//只删除第一次出现的。
	{
		int index = Find(a);
		if (index == -1)
			return false;
		int count = strlen(a);
		char* str1 = m_str + index + count;
		int i = 0;
		while (1)//删除找到的a串
		{
			m_str[index + i] = str1[i];
			if (str1[i] == 0)
				break;
			i++;
		}
		m_length -= count;
		return true;
	}
	int Find(const char* a) 
	{
		int count = strlen(a);
		int i = 0;
		bool findit = false;
		for (int k = 0; k <= m_length - count; ++k)
		{
			if (m_str[k] == a[i])
			{
				for (int j = 0; j <= count; ++j)
				{
					if (m_str[k + j] != a[i + j])
					{
						if (a[i + j] == 0)
						{
							findit = true;
							return k;
						}
						break;
					}
				}
			}
		}
		return -1;
	}
	bool Replace(const char* old, const char* target)//替换新值
	{
		
		int index = Find(old);
		int oldcount = strlen(old);
		if (index == -1)
			return false;
		char* str1, * str2;
		m_str[index] = 0;
		str1 = m_str;
		str2 = (m_str + (index + oldcount));
		char* temp = (char*)malloc(m_size);
		int i = 0;
		while (str1[i])
		{
			temp[i] = str1[i++];
		}
		int j = 0;
		while (target[j])
		{
			temp[i + j] = target[j++];
		}
		int k = 0;
		while (str2[k])
		{
			temp[i + j + k] = str2[k++];
		}
		temp[i + j + k] = 0;
		m_length = 0;
		for (i = 0; temp[i]; ++i)
		{
			m_length++;
			m_str[i] = temp[i];
		}
		free(temp);
		m_str[i] = 0;
	}
};
void main()
{
	CMystr a, b;
	a.insert("aaabbb");//a为aaabbb
	b.insert("bbb");//b为bbb
	CMystr c = a;//c此时等于aaabbb
	c = b;//c此时等于bbb
	c = a + b;//c此时等于aaabbbbbb
	char ca = c.At(5);//ca为b
	c.erase("aa");//c为abbbbbb
	c.Replace("bb", "ccd");//c为accdbbbb
	system("pause");
}