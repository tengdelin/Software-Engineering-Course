#include<iostream>
using namespace std;
template<typename T, int n>
class M {
	T a[n];
public:
	M() {}
	M(const std::initializer_list<T>&);
	int search(T);
	void print();
};
template<typename T, int n>
M<T, n>::M(const std::initializer_list<T>& l) :a{ T() }
{
	int m = l.size() < n ? l.size() : n;
	for (int i = 0; i < m; i++)
		a[i] = *(l.begin() + i);
}
template<typename T, int n>
int M<T, n>::search(T temp)
{
	for (int i = 0; i < n; i++)
		if (temp == a[i])
			return i;

	return -1;
}
template<typename T, int n>
void M<T, n>::print() {
	T t;
	cout << "������Ҫ���ҵ�Ԫ��:";
	cin >> t;
	int m = search(t);
	if (m == -1)
		cout << "�޴�Ԫ�أ�" << endl;
	else
		cout << "Ҫ���ҵ�Ԫ���±�Ϊ:" << m << endl;
}
int main() {
	M<string, 4>str1 = { "a","ci","wen","q","ll" };
	str1.print();
	return 0;
}