#include<iostream>
using namespace std;
template<typename T>
void sort(T *a, int n)
{
	for (int i = 0; i < n-1; i++)
	{
		for (int j = 0; j < n - 1 - i; j++)
		{
			if (a[j] < a[j+1]) 
			{
				T temp;
				temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
			}
		}
	}
}
int main() {
	string str1[5] = { "c","g","a","b","q" };
	sort<string>(str1, 5); 
	for (auto i : str1)
		cout << i << ",";
	cout << endl;
	return 0;
}