#include<iostream>
#include<string>
#include<stdio.h>
using namespace std;
template<typename T, int n>
class Aclass {
public:
	int search(T);
	Aclass() {
		size = n;
		a = new T[size];//���캯����ʼ��
	}
	void getelement(T value, int b) {//����Ա���ݸ�ֵ

		a[b] = value;        
	}
	~Aclass() {
		delete[]a;
	}
private:
	T* a;
	int size;
};
template<typename T, int n >
int Aclass<T, n>::search(T t) {
	int i = 0,j=0; 
	int tmp = 0;//��¼״̬
	
	for (;i < n;i++) {
		if (a[i] == ' ') {
			tmp = 0;//�����������������ַ�
			break;
		}
		else tmp = 1;//����������������
	}
	if (tmp == 0)//�������������ַ���ʱ
	{
		for (int i = 0;i < n;i++) {
			if (a[i] == t && a[i] != ' ') {
				while (tmp != 1) {
					cout << "��⵽�����ı����������������ݣ�" << endl;//��⵽���������ı�
					tmp = 1;
				}
				while (a[j+1] != ' '&&j+1<n) {
					cout << a[j+1];//������иùؼ��ʵ��ı� 
					j++;
				}
				cout << " ";
			}
			else if (a[i] == ' ') {
				j = i;//��¼�ո��λ��
			}
			else continue;
		}
		if (tmp == 0) {
			cout << "���ı��в�����������Ԫ�ء�" << endl;//��û�����������þ����
		}
	}
	return tmp;
}
int main() {
	int a[5] = { 1,2,3,4,5 };
	Aclass<int, 4> A;
	for (int i = 0;i <4;i++) {
		A.getelement(a[i], i);
	}
	cout << A.search(1) << endl;
	cout << A.search(10) << " ";
	string b="tom abbb app";
	Aclass<char, 13>B;
	for (int i = 0;i < 13;i++) {
		B.getelement(b[i], i);
	}char bl;
	do {
		system("cls");
		//����������Ԫ��
		cout << "����������Ҫ���ҵ�Ԫ�أ�(��0������ѯ)" << endl;
		cin >> bl;
		B.search(bl);
		system("pause");
	} while (bl!='0');

	return 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
}