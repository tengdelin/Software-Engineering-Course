#include<iostream>
#include<string>
using namespace std;
template<typename T>
void sort(T a, int n) {
	for (int i = 0;i < n; i++) {
		for (int j = 0;j < n - i - 1;j++) {
			if (a[j]> a[j+1]) {
				T tmp =a[j];
				a[j] = a[j + 1];
				a[j + 1] = tmp;
			}
		}
	}
}
int main() {
	string a = "rcjgdds" ;
	sort(a, 10);
	for (int i = 0;i < 10;i++)cout << a[i] << " ";
	return 0;
}