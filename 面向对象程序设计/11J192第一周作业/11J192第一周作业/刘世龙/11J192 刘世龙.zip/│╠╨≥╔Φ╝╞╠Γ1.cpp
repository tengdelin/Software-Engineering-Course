﻿/*设计一个函数模板，其中包括数据成员T a[n]以及对其进行排序的成员函数sort( )
，模板参数T可实例化成字符串。*/
#include <iostream>
#include <string>
using namespace std;
template<class T>void sort(T* s, int n)
{
	T t;
	for (int i = 0; i < n - 1; i++)  //进行排序
		for (int j = 0; j < n - 1; j++)
			if (s[j] > s[j + 1])
			{
				t = s[j];
				s[j] = s[j + 1];
				s[j + 1] = t;
			}
	for (int i = 0; i < n; i++) //输出排序后的结果
		cout << s[i] << " ";
	cout << endl;
}

int main()
{
	string name[8] = { "zhao","qian","sun","li","zhou","wu","zheng","wang" };
	int number1[6] = { 9,14,6,10,8,5 };
	double number2[7] = { 3.1,2.7,1.4,9.2,6.5,3.5,6.7 };
	sort<string>(name,8);
	sort<int>(number1, 6);
	sort<double>(number2, 7);
	return 0;
}