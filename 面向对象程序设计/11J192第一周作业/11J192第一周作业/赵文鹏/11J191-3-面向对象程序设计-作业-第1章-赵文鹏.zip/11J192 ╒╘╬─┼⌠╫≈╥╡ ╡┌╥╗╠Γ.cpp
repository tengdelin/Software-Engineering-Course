﻿#include<iostream>/*函数模板的定义形式是template<模板参数表> 返回类型 函数名（形式参数表）{…}*/
#include<string>
using namespace std; /*1．设计一个函数模板，其中包括数据成员T a[n]以及对其进行排序的成员函数sort( )，模板参数T可实例化成字符串。*/
template<typename T>void sort(T* a,int n) {
	int i, j;
	T b;
	for (i = 0; i < n - 1; i++) {/*运用冒泡排序对数组里面的数据进行排序*/
		for (j = 0; j < n - i - 1; j++) {
			if (a[j] > a[j + 1]) {
				b = a[j];
				a[j] = a[j + 1];
				a[j + 1] = b;
			}
		}
	}
}template<typename T>void look(T* a, int n) {/*构造另一个函数模板访问数组*/
	int i;
	for (i = 0; i < n ; i++) {
		cout << a[i] << "  ";
	}
}
int main() {
	string a[5] = { "e","d","c","b","a" };
	sort(a, 5);/*匹配到相应函数模板，编译器实例出一个模板函数*/
	look(a, 5);
	int b[5] = { 5,4,3,2,1 };
	sort(b, 5);/*匹配到相应函数模板，编译器实例出一个模板函数*/
	look(b, 5);
	return 0;

}