#include<iostream>
#include<string>
using namespace std;
template<class T, int n>
class A {
public:
	int search(T);
	A();
	void setyuansu(T value, int b) {
		a[b] = value;
	};
	~A();
private:
	T* a;
	int size;
};
template<class T, int n>A<T, n>::A() {
	size = n;
	a = new T[size];/*�����ڴ����ģ�*/
}; 
template<class T, int n>A<T, n>::~A() {
	delete[]a;
};


template<typename T, int n >
int A<T, n>::search(T t) {
	int i ,j=0; 
	int str = 0;
	
	for (i=0;i < n;i++) {
		if (a[i] == ' ') {
			str = 0;//�����������������ַ�
			break;
		}
		else str = 1;//�������ַ����������������
	}
	if (str == 0)
	{
		for (int i = 0;i < n;i++) {
			if (a[i] == t && a[i] != ' ') {
				while (str != 1) {
					cout << "��⵽�����ı����������������ݣ�" << endl;
					str = 1;
				}
				while (a[j+1] != ' '&&j+1<n) {
					cout << a[j+1];
					j++;
				}
				cout << " ";
			}
			else if (a[i] == ' ') {
				j = i;
			}
			else continue;
		}
		if (str == 0) {
			cout << "û���ҵ�����ַ�������" << endl;
		}
	}
	return str;
}
int main() {
	int a[5] = { 1,2,3,4,5 };
	A<int, 4> A1;
	for (int i = 0;i <4;i++) {
		A1.setyuansu(a[i], i);
	}
	cout << A1.search(1) << endl;
	cout << A1.search(10) << " ";
	string b="Tom is a boy";
	A<char, 13>A2;
	for (int i = 0;i < 13;i++) {
		A2.setyuansu(b[i], i);
	}char bl;
	do {
		system("cls");
		cout << "��������Ҫ���ҵ�Ԫ�أ�(��0������ѯ)" << endl;
		cin >> bl;
		A2.search(bl);
		system("pause");
	} while (bl!='0');

	return 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
}