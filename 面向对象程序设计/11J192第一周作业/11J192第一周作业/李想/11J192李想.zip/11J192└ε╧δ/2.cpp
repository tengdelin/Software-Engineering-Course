#include <iostream>
#include <string>
using namespace std;
template<typename T, int n>
class A {
	int size;
	T* s��
public:
	A();
	~A();
	int search(T);
};
template<typename T, int n>
A<T, n>::A() {
	size = n;
	s = new T[size];
}
template<typename T, int n>
A<T, n>::A() {
	delete[]s;
}
template<typename T, int n>
int A<T, n>::search(T t) {
	int i;
	for (i = 0; i < size; i++) {
		if (s[i] == t)
			return I;
		return -1
	}


