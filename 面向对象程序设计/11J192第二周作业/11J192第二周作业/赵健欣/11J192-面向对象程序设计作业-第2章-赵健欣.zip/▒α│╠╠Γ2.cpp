#include <iostream>
#include   <math.h>
using namespace std;
class point {
	friend rectangle;
public:
	point();
	point(double c, double d) {
		x = c;
		y = d;
	}
	point(const point& p) {
		x = p.x;
		y = p.y;
	}
	void print();
	double x;
	double y;
};
void point::print() {
	cout << "�����꣺" << x << "�����꣺" << y << endl;
}
class rectangle {
	friend point;
public:
	rectangle();
	rectangle(point p0, int x, int y);
	rectangle(rectangle& rp);
	double CalLen() {
		double sum = 2*(X2 - P1.x)  + 2*(Y2 - P1.y) ;
		return sum;
	}
	double Square() {
		double sum = (X2 - P1.x) * (Y2 - P1.y);
	}
	~rectangle();
	 point P1;
	 int X2, Y2;
};
rectangle::rectangle() {
	X2 = 0;
	Y2 = 0;
	cout << "he default conclassor is called!" << endl;
}
rectangle::rectangle(point p0, int x, int y) :P1(p0) {
	X2 = x;
	Y2 = y;
	cout << "conclassor is called!" << endl;
}
rectangle::rectangle(rectangle& rp) {
	P1 = rp.P1;
	X2 = rp.X2;
	Y2 = rp.Y2;
	cout << "copy conclassor is called!" << endl;
}
rectangle::~rectangle() {
	cout << "declassor is called! " << "X2=" << X2 << ",Y2=" << Y2 << endl;
}
int main() {
	int a, b, c, d;
	cout << "����������������꣺" << endl;
	cin >> a >> b >> c >> d;
	point A(a, b);
	rectangle B(A, c, d);
	cout << "�����ܳ��ǣ�" << B.CalLen() << endl;
	cout << "���������" << B.Square()<< endl;
}