#include <iostream>
using namespace std;
class juzhen {
public:
	juzhen(float c[4][4], float d[4][4]) {
		for (int i; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				a[i][j] = c[i][j];
				b[i][j] = d[i][j];
			}
		}
	}
	void chengfa();
	void print();
private:
	float a[4][4];
	float b[4][4];
	float result[4][4];
};
void juzhen::print() {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			cout << a[i][j] << "  ";
		}
	}
}
void juzhen::chengfa() {
	for (int k = 0; k < 4; k++) {
		for (int i = 0; i < 4; i++) {
			result[i][k] = 0.0;
			for (int j = 0; j < 4; j++) {
				result[i][k] = result[i][k] + a[i][j] * b[j][k];
				cout << result[i][k] << "   ";
			}
		}
	}
}

int main(){
	float c[4][4]= { {1, 2, 3, 4}, {2, 3, 4, 5}, {3, 4, 5, 6}, {4, 5, 6, 7} };
	float d[4][4]= { {2, 3, 4, 5}, {3, 4, 5, 6}, {4, 5, 6, 7}, {5, 6, 7, 8} };
	juzhen a( float c[4][4],float d[4][4] );
	a.chengfa();
}
 