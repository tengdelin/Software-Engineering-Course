﻿#include <iostream>
using namespace std;
#include "mycomplex.h"

//有参构造函数
CComplex::CComplex(double r, double i)
{
	m_real = r;
	m_image = i;
}

//拷贝构造函数
CComplex::CComplex(const CComplex& c)
{
	m_real = c.m_real;
	m_image = c.m_image;
}

//加法运算
CComplex CComplex::operator+(const CComplex& c) const
{
	CComplex he;
	he.m_real = m_real + c.m_real;
	he.m_image = m_image + c.m_image;
	return he;
}
//减法运算
CComplex CComplex::operator-(const CComplex& c)const
{
	CComplex cha;
	cha.m_real= m_real - c.m_real;
	cha.m_image = m_image - c.m_image;
	return cha;
}
//乘法运算
CComplex CComplex::operator*(const CComplex& c)const
{
	CComplex ji;
	ji.m_real = m_real * c.m_real - m_image * c.m_image;
	ji.m_image = m_real * c.m_image + m_image * m_real;
	return ji;
}
//打印出复数的内容：
void CComplex::print()
{
	if (m_image > 0)
	{
		cout << "复数" << m_real << "+" << m_image << "i" << endl;
	}
	else if (m_image == 0)
	{
		cout << "实数" << m_real << endl;
	}
	else
	{
		cout << "复数" << m_real << "-" << fabs(m_image) << "i" << endl;
	}

}
int main()
{
	int x1, y1, x2, y2;
	cout << "请分别输入两数的实部与虚部：" << endl;
	cin >> x1 >> y1 >> x2 >> y2;
	CComplex a(x1,y1), b(x2,y2), he,cha,ji;
	he = a + b;  cha = a - b;  ji = a * b;
	he.print();   cha.print();   ji.print();
	return 0;
}