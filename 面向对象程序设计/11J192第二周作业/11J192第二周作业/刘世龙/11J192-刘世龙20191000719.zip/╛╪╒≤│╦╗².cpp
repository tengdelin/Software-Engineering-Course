﻿/* 求矩阵的乘积(4*4 4*4)
定义4设A=(a ij)是一个 m*s矩阵,B=(b ij)是一个s*n矩阵,那么
规定矩阵A与矩阵B的乘积是一个m*n矩阵C=(c ij),并把此乘积记作：C= AB
（1）设计一个支持矩阵乘运算的类或类模板；
（2）从文件中读取测试数据，输入到矩阵对象中，编制测试程序进行调用。*/

#include <iostream>
using namespace std;
class Cmatrix
{
private:
	int m_hang1, m_lie1;
	int m_hang2, m_lie2;//两矩阵的行和列
public:
	//构造函数，内联函数
	Cmatrix(int m, int s, int n)
	{
		m_hang1 = m; m_lie1 = s;
		m_hang2 = s; m_lie2 = n;
	}
	//矩阵乘积函数
	void multiply(int A[100][100], int B[100][100])
	{
		int multiply[100][100], i, j;
		cout << "A,B矩阵乘积C矩阵为：" << endl;
		for (i = 0; i < m_hang1; i++)
		{
			for (j = 0; j < m_lie2; j++)
			{
				multiply[i][j] = 0;//赋初值
				for (int k = 0; k < m_lie1; k++)
				  //根据运算规律计算矩阵所含元素值
					multiply[i][j] += A[i][k] * B[k][j];				
				cout << multiply[i][j] << " ";//输出乘积矩阵
			}
			cout << endl;
		}
	}
};
int main()
{
	int m, s, n;
	cout << "请分别输入A矩阵的行，列与B矩阵的列：" << endl;
	cin >> m >> s >> n;
	Cmatrix multiply(m, s, n);
	int i, j, A[100][100], B[100][100];
	cout << "请输入A矩阵：" << endl;
	for (i = 0; i < m; i++)//输入矩阵A
		for (j = 0; j < s; j++)
			cin >> A[i][j];
	cout << "请输入B矩阵：" << endl;
	for (i = 0; i < s; i++)//输入矩阵B
		for (j = 0; j < n; j++)
			cin >> B[i][j];
	multiply.multiply(A, B);
	return 0;
}