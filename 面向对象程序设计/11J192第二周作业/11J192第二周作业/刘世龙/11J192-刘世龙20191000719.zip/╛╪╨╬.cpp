﻿/*2.定义一个二维平面上的点类，点的坐标为整型，类中要具有以下功能:
  （1)求点的横坐标;  （2)求点的纵坐标。
定义一个矩形的类;矩形位置由左上角点和右下角点所组成，在矩形类中要使用已定义的点类,
矩形类中要具有以下功能:
  （1)求矩形的面积;  （2)求矩形的周长。
在主函数中，实现以下功能:
  （1) 输入左上角点和右下角点的坐标;
  （2)使用输入的点， 定义-一个矩形类的对象，计算矩形的周长和面积，并输出计算结果。*/
#include <iostream>
using namespace std;
class Cpoint
{
private:
	int m_x, m_y;
public:
	//构造函数，内联函数
	Cpoint(int x, int y)
	{
		m_x = x; m_y = y;
		cout << "点的横纵坐标分别为：" << m_x << " " << m_y << endl;
	}
	//友元类，使矩形类可访问点类数据成员
	friend class Crectangle;
};
class Crectangle
{
private:

	int m_x1, m_y1, m_x2, m_y2;
public:
	//调用点类中的参数
	Crectangle(Cpoint A, Cpoint B)//A,B代表两点
	{
		m_x1 = A.m_x; m_y1 = A.m_y;
		m_x2 = B.m_x, m_y2 = B.m_y;
	}
	double  cir()   //周长函数
	{
		return (2 * (abs(m_x1 - m_x2) + abs(m_y1 - m_y2)));
	}
	double area()  //面积函数
	{
		return abs((m_x1 - m_x2) * (m_y1 - m_y2));
	}
};
int main()
{
	int x1, y1, x2, y2;//两点横纵坐标
	cout << "请分别输入矩形的左上角与右上角横纵坐标：" << endl;
	cin >> x1 >> y1 >> x2 >> y2;
	Cpoint A(x1, y1);//传递实参
	Cpoint B(x2, y2);
	Crectangle output(A, B);
	cout << "矩形的周长为：" << output.cir() << " 面积为：" << output.area();
	return 0;
}